export default function Home() {
  return (
    <div className="min-h-screen bg-black text-white flex flex-col items-center justify-center p-4">
      <h1 className="text-4xl font-bold mb-4">Swiss Aureus Group</h1>
      <p className="text-lg text-center max-w-xl">
        Bienvenido a la plataforma Aureus Financial. Excelencia en gestión financiera, tecnología blockchain, inteligencia artificial y soluciones de inversión.
      </p>
    </div>
  );
}
