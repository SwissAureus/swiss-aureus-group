# Swiss Aureus Group
Plataforma integral para gestión de fondos con IA y blockchain.