export default function Home() {
  return (
    <main className="min-h-screen bg-gray-950 text-white flex flex-col items-center justify-center p-8">
      <h1 className="text-4xl md:text-6xl font-bold mb-6 text-yellow-400">
        Swiss Aureus Group
      </h1>
      <p className="text-lg md:text-xl text-gray-300 text-center max-w-xl">
        Plataforma integral para gestión de fondos, análisis predictivo y soluciones blockchain.
      </p>
    </main>
  );
}